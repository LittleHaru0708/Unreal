<?php
mhpinfo();
?>